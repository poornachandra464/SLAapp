import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BsDatepickerModule, PaginationModule, ProgressbarModule  } from 'ngx-bootstrap';
import { ToasterModule } from 'angular2-toaster';
import { MatDialogModule, MatNativeDateModule } from '@angular/material';
import { NgxDocViewerModule } from 'ngx-doc-viewer';
import { NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { MatToolbarModule, MatIconModule, MatSidenavModule, MatListModule, MatButtonModule } from  '@angular/material';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './common/login/login.component';
import { DashboardModule  } from './dashboard/dashboard.module';
import { AlertComponent } from './common/Error/alert.component';
import { AuthInterceptor } from './interceptors/AuthInterceptor';
import { ErrorInterceptor } from './interceptors/ErrorInterceptor';
import { ProvidersModule } from './provider/providers.module';

// used to create fake backend
import { fakeBackendProvider } from './fake-backend';
import {HeaderComponent} from '../app/common/header/header.component';
import {FooterComponent} from '../../src/app/common/footer/footer.component'

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AlertComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    Ng4LoadingSpinnerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    ProgressbarModule.forRoot(),
    ToasterModule.forRoot(),
    NgxDocViewerModule,
    MatDialogModule,
    MatNativeDateModule,
    DashboardModule,
    ProvidersModule,
    NgxMaterialTimepickerModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatIconModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    fakeBackendProvider
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
