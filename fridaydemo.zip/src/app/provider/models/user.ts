export class User {
    UserName: string;
    Password: string;
}