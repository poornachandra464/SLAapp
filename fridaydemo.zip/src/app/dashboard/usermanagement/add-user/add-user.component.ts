import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../../provider/services/dashboard.service';
import { IdTextModel } from 'src/app/provider/models/IdTextModel';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from './MustMatch';
import { CallFlowData } from 'src/app/provider/models/CallFlowData';
import { UserModel } from 'src/app/provider/models/UserModel';
import { ToasterService } from 'angular2-toaster';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  NewUserForm:FormGroup;
  submitted=false;
  Teams:IdTextModel[];
  CallFlowDatas:CallFlowData[];
  callFlowdata:CallFlowData;
  AddUserModel:UserModel;
  callflowadmin:CallFlowData[];


  
  constructor(private dashboardService: DashboardService,private formBuilder:FormBuilder,private toasterService: ToasterService) {
    this.AddUserModel={
      userName:"",
      password:"",
      accountType:"",
      callFlows:[],
    },
    this.CallFlowDatas=[],
    this.callflowadmin=[]
  
  }
  
  private getTeamsdetails() {
    this.dashboardService.Teamdetails().subscribe((data: any) => {
       this.Teams=data;
       //console.log(data);
       this.construct()}
      
       );
  }
    ngOnInit() {

      this.NewUserForm = this.formBuilder.group({
        username: ['', Validators.required,],
        password: ['', Validators.required],
        Role: ['',Validators.required],
        
        confirmPassword: ['', Validators.required]
        }, {
            validator: MustMatch('password', 'confirmPassword')
        });
        this.getTeamsdetails();
        
    }
    
   construct(){
    
     for(let i=0;i<this.Teams.length;i++)
    
     {
       this.CallFlowDatas.push({CallFlowId:this.Teams[i].id,Value:false});
       this.callflowadmin.push({CallFlowId:this.Teams[i].id,Value:true});
       //callflowarray.push({callFlowId: i < 9 ? "0" + (i + 1) : (i + 1).toString(), value: false});
     }
     
     
     //console.log(this.CallFlowDatas);
   }
   
   get f() { return this.NewUserForm.controls; }
   onchange(e,index)
   {
     if(e.target.checked){
       this.CallFlowDatas[index].Value=true;
      // console.log(this.CallFlowDatas);
     }
   }
  /* callflowselect(e)
   {
     if(e.target.value=="01")
     {
      for(let i=0;i<this.CallFlowDatas.length;i++){
        this.CallFlowDatas[i].value=true;
     }
   }
   else if(e.target.value=="02")
   {
      this.CallFlowDatas=this.CallFlowDatas;
   }
   }*/

   onSubmit() {
        this.submitted = true;
        if (this.NewUserForm.invalid) {
            return;
        }
        
        console.log(this.NewUserForm.get('username').value);

        
        
        this.AddUserModel.userName= this.NewUserForm.get('username').value;
        this.AddUserModel.password= this.NewUserForm.get('password').value;
        //this.AddUserModel.callFlows=this.CallFlowDatas;
        if(this.NewUserForm.get('Role').value=="02"){
          this.AddUserModel.callFlows=this.CallFlowDatas;
          this.AddUserModel.accountType="02";
        }
        else{
          
          this.AddUserModel.accountType="01";
        this.AddUserModel.callFlows=this.callflowadmin;}

        console.log(this.AddUserModel.callFlows);
        

       /* if(this.AddUserModel.accountType=="02"){
          this.AddUserModel.callFlows=this.CallFlowDatas;
        }
        else{  for(let i=0;i<this.CallFlowDatas.length;i++){
          this.AddUserModel.callFlows[i].value=true;
      
        console.log(this.AddUserModel.callFlows);*/
        this.dashboardService.AddNewUserDetails(this.AddUserModel).subscribe(
          data => {
             this.toasterService.pop("success", "AddUser", "Add user has been updated successfully");
           },
           error => {
             this.toasterService.pop("error", "AddUser", "Server error has occured!!!");
           });
    }
  
    

}
