import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-addInbound',
  templateUrl: 'addInbound.component.html',
})
export class AddInboundComponent {

  constructor(
    public dialogRef: MatDialogRef<AddInboundComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onAddClick(): void{
    this.dialogRef.close(this.data.location);
  }

}