import { Component, OnInit, ElementRef } from '@angular/core';
import { DashboardService } from '../../provider/services/dashboard.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { MatDialog } from '@angular/material';
import {AddLocationComponent} from './addlocation/addlocation.component';

@Component({
  selector: 'app-generalsettings',
  templateUrl: './generalsettings.component.html',
  styleUrls: ['./generalsettings.component.css']
})
export class GeneralSettingsComponent implements OnInit {
  generalSettingsForm: FormGroup;
  locationNames:any;
  callValues=[];
  private element: any;
  constructor(private dashboardService: DashboardService,
    private formBuilder: FormBuilder,
    private toasterService: ToasterService,
    public dialog: MatDialog,private el: ElementRef) {
      this.element = el.nativeElement;
  }
  ngOnInit() {
    this.createForm();
    this.callValues = Array(20).fill(0).map((x,i)=>i+1);
    
    this.dashboardService.getGeneralSettings().subscribe(
      data => {
       this.generalSettingsForm.patchValue({
        timecall:data.general.agentTimeout
        });
      this.locationNames=data.locations
      },
      error => {
      });
  }

  createForm() {
    this.generalSettingsForm = this.formBuilder.group({
      timecall: ['', ''],
      locations: [[], ''],
    });
  }

  get f() { return this.generalSettingsForm.controls; }

  onTextChange(existingValue,newValue){
  let index=this.locationNames.indexOf(existingValue);
  this.locationNames[index].text=newValue;
  }

  onSubmit() {
    var item={
      'general':{
        'agentTimeout': this.generalSettingsForm.get('timecall').value,
        'locCounter': this.locationNames.length
      },
      'locations': this.locationNames,
     }
    this.dashboardService.updateGeneralSettings(item).subscribe(
      data => {
        this.toasterService.pop("success", "General Call Flow Settings", "File has been updated successfully");
      },
      error => {
        this.toasterService.pop("error", "General Call Flow Settings", "Server error has occured!!!");
      });
  }

  OnRemoveClick(location){
   let indexValue= this.locationNames.indexOf(location);
   this.locationNames.splice(indexValue,1);
  }

  openDialog(): void {
    //this.element.style.display = 'none';
    let dialogRef = this.dialog.open(AddLocationComponent, { 
      panelClass:'custom-dialog-container',
      width: '350px',
      data: {location:''},
      backdropClass: 'dialogBackground',
    });

    dialogRef.afterClosed().subscribe(result => {
      //this.element.style.display = 'block';
      if(result){
        var item={
          'id':(this.locationNames.length+1).toString(),
          'text':result
        }
      this.locationNames.push(item);
      }
    });
  }
}
