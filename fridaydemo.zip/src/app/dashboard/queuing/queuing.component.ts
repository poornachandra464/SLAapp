import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DashboardService } from 'src/app/provider/services/dashboard.service';
import { ToasterService } from 'angular2-toaster';
import { QueueModel } from 'src/app/provider/models/QueueModel';


@Component({
  selector: 'app-queuing',
  templateUrl: './queuing.component.html',
  styleUrls: ['./queuing.component.css']
})
export class QueuingComponent implements OnInit {

  QueuingForm: FormGroup;
  Outputdata:QueueModel;
  messageRequiredArray:number[];
  selectedDropdownValue: number;
  valuechange:number;
  constructor(private dashboardService: DashboardService,
    private formBuilder: FormBuilder,
    private toasterService: ToasterService) {
      this.Outputdata={
      inQueueMessageDelay:null,
      enablePositionInQueue:null,
      voicemailOptionEnabled:null,
      voicemailOptionTimeout:null,
      voicemailOptionDN:'',
      messageOrder:null,
      messageNumber:null,
      enableDivertTime:null,
      enableDivertTimeTimer:null,
      enableDivertTimeNumber:'',
      enableDivertCallers:null,
      enableDivertCallersLevel:null,
      enableDivertCallersNumber:'',
      id:'',
      };
    
   }
  ngOnInit() {
  //  this.msg=3;
  
    //  this.messageRequiredArray=Array(this.msg).fill(1).map((x,y)=>y+1);
     // this.selectedDropdownValue=this.msg;

      this.createForm();
      this.dashboardService.getQueuingDetails().subscribe(
        data => {
          this.QueuingForm.setValue({
            inQueueMessageDelay:data.inQueueMessageDelay,
            enablePositionInQueue:data.enablePositionInQueue,
            voicemailOptionEnabled:data.voicemailOptionEnabled,
            voicemailOptionTimeout:data.voicemailOptionTimeout,
            voicemailOptionDN:data.voicemailOptionDN,
            messageOrder:data.messageOrder,
            messageNumber:data.messageNumber,
            enableDivertTime:data.enableDivertTime,
            enableDivertTimeTimer:data.enableDivertTimeTimer,
            enableDivertTimeNumber:data.enableDivertTimeNumber,
            enableDivertCallers:data.enableDivertCallers,
            enableDivertCallersLevel:data.enableDivertCallersLevel,
            enableDivertCallersNumber:data.enableDivertCallersNumber,  
          });
          this.messageRequiredArray=Array(this.QueuingForm.get('messageNumber').value).fill(1).map((x,y)=>y+1);
          this.selectedDropdownValue=this.QueuingForm.get('messageNumber').value;
          this.Outputdata.id=data.id;
          this.valuechange=this.selectedDropdownValue;
        },
        error => {
        });

  }


  OnDropDownChange(value: string) {
    this.valuechange= Number(value);
  }
  createForm() {
    this.QueuingForm = this.formBuilder.group({
      inQueueMessageDelay:['',''],
      enablePositionInQueue:['',''],
      voicemailOptionEnabled:['',''],
      voicemailOptionTimeout:['',''],
      voicemailOptionDN:['',''],
      messageOrder:['',''],
      messageNumber:['',''],
      enableDivertTime:['',''],
      enableDivertTimeTimer:['',''],
      enableDivertTimeNumber:['',''],
      enableDivertCallers:['',''],
      enableDivertCallersLevel:['',''],
      enableDivertCallersNumber:['',''],
    });
  }



  
  get f() { return this.QueuingForm.controls; }

  
    onSubmit() {
      this.Outputdata.inQueueMessageDelay = this.QueuingForm.get('inQueueMessageDelay').value;
      this.Outputdata.enablePositionInQueue = this.QueuingForm.get('enablePositionInQueue').value;
      this.Outputdata.voicemailOptionEnabled = this.QueuingForm.get('voicemailOptionEnabled').value;
      this.Outputdata.voicemailOptionTimeout = this.QueuingForm.get('voicemailOptionTimeout').value;
      this.Outputdata.voicemailOptionDN      = this.QueuingForm.get('voicemailOptionDN').value;
      this.Outputdata.messageOrder= this.QueuingForm.get('messageOrder').value;
      this.Outputdata.messageNumber= this.valuechange;
      this.Outputdata.enableDivertTime= this.QueuingForm.get('enableDivertTime').value;
      this.Outputdata.enableDivertTimeTimer= this.QueuingForm.get('enableDivertTimeTimer').value;
      this.Outputdata.enableDivertTimeNumber= this.QueuingForm.get('enableDivertTimeNumber').value;
      this.Outputdata.enableDivertCallers= this.QueuingForm.get('enableDivertCallers').value;
      this.Outputdata.enableDivertCallersLevel= this.QueuingForm.get('enableDivertCallersLevel').value;
      this.Outputdata.enableDivertCallersNumber= this.QueuingForm.get('enableDivertCallersNumber').value;
      this.dashboardService.updateQueuing(this.Outputdata).subscribe(
       data => {
          this.toasterService.pop("success", "Queuing", "File has been updated successfully");
        },
        error => {
          this.toasterService.pop("error", "Queuing", "Server error has occured!!!");
        });
    
    }
    
  
 /* ************************************************************************** 
 Queuedata:QueueModel;
 messageRequiredArray:number[];
 selectedDropdownValue: number;
 constructor(private dashboardService: DashboardService,private toasterService: ToasterService) {}

 ngOnInit() {
   this.GetQueuedata();
 }

  GetQueuedata()
    {
  this.dashboardService.getQueuingDetails().subscribe(
    data => {
      this.Queuedata=data;
      
      console.log(this.Queuedata);
      this.messageRequiredArray=Array(this.Queuedata.messageNumber).fill(1).map((x,y)=>y+1);
      this.selectedDropdownValue=this.Queuedata.messageNumber;
    },
    error => {
    });


     }

     onSubmit()
     {   
      this.dashboardService.updateQueuing(this.Queuedata).subscribe(
        data => {
          this.toasterService.pop("success", "Queuing", "File has been updated successfully");
        },
        error => {
          this.toasterService.pop("error", "Queuing", "Server error has occured!!!");
        });
     }
     OnDropDownChange(value: string) {
       this.Queuedata.messageNumber= Number(value);

    }*/
    

}
