export class OutOfHours {
  enableMessageOOH: boolean;
  enableVoicemailRedirectOOH: boolean;
  dnOOH: string;
  enableMessageBankHoliday: boolean;
  enableVoicemailRedirectBankHoliday: boolean;
  dnBankHoliday: string;
  id: string;
}