import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../provider/services/dashboard.service';
import { FormGroup, FormBuilder,FormControl } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { MatDialog } from '@angular/material';
import { AddInboundComponent } from './addInbound/addInbound.component';

@Component({
  selector: 'app-generalcallsettings',
  templateUrl: './generalcallsettings.component.html',
  styleUrls: ['./generalcallsettings.component.css']
})
export class GeneralCallSettingsComponent implements OnInit {
  generalSettingsForm: FormGroup;
  locationNames:Array<string>=['Headquaters','AUP (IS)'];
  inboundNumbers:any;
  callValues=[];
  callFlowId:any;
  constructor(private dashboardService: DashboardService,
    private formBuilder: FormBuilder,
    private toasterService: ToasterService,
    public dialog: MatDialog) {
  }
  ngOnInit() {
    this.createForm();
    this.callValues = Array(20).fill(0).map((x,i)=>i+1);
    
    this.dashboardService.getGeneralCallFlowSettings().subscribe(
      data => {
        console.log(data)
        this.generalSettingsForm.patchValue({
          isGenericMessageEnabled: data.callFlowGeneral.genericMessages,
          isCallFlowMessageEnabled: data.enableWelcomeMessage,
          location: this.locationNames[(data.callFlowGeneral.location-1)],
        });
        this.inboundNumbers=data.routePoints;
        this.callFlowId = data.id;
        console.log(this.inboundNumbers);
      },
      error => {
      });
  }

  createForm() {
    this.generalSettingsForm = this.formBuilder.group({
      isGenericMessageEnabled: ['', ''],
      isCallFlowMessageEnabled: ['',''],
      inboundNumber:new FormControl({value:'',disabled: true}),
      location:['','']
    });
  }

  get f() { return this.generalSettingsForm.controls; }

  onSubmit() {
    var item={
      'callFlowGeneral':{
      'genericMessages':this.generalSettingsForm.get('isGenericMessageEnabled').value,
      'location':(this.locationNames.indexOf(this.generalSettingsForm.get('location').value))+1,
      },
      'enableWelcomeMessage': this.generalSettingsForm.get('isCallFlowMessageEnabled').value,
      'id': this.callFlowId,
      'routePoints':this.inboundNumbers
     }
     console.log(item);
    this.dashboardService.updateGeneralCallFlowSettings(item).subscribe(
      data => {
        this.toasterService.pop("success", "General Call Flow Settings", "File has been updated successfully");
      },
      error => {
        this.toasterService.pop("error", "General Call Flow Settings", "Server error has occured!!!");
      });
  }

  OnRemoveClick(inboundValue){
   let indexValue= this.inboundNumbers.indexOf(inboundValue);
   this.inboundNumbers.splice(indexValue,1);
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(AddInboundComponent, { 
      panelClass:'custom-dialog-container',
      width: '400px',
      data: {location:''},
      backdropClass: 'dialogBackground'
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
      var item={
        'id':result,
        'text':this.callFlowId
      }
      this.inboundNumbers.push(item);
      }
    });
  }
}
