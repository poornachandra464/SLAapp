import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../provider/services/dashboard.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';

@Component({
  selector: 'app-noagents',
  templateUrl: './noagents.component.html',
  styleUrls: ['./noagents.component.css']
})
export class NoAgentsComponent implements OnInit {
  noagentsForm: FormGroup;
  callFlowId:any;
  constructor(private dashboardService: DashboardService,
    private formBuilder: FormBuilder,
    private toasterService: ToasterService) {
  }
  ngOnInit() {
    this.createForm();
    this.dashboardService.getNoAgents().subscribe(
      data => {
        this.noagentsForm.setValue({
          ismessageEnabled: data.noAgentsPrompt,
          isCallEnabled: data.noAgentsDivert,
          divertedNumber: data.noAgentsDN,     
        });
        this.callFlowId = data.id;
      },
      error => {
      });
  }

  createForm() {
    this.noagentsForm = this.formBuilder.group({
      ismessageEnabled: ['', ''],
      isCallEnabled: ['', ''],
      divertedNumber: ['', ''],
    });
  }

  get f() { return this.noagentsForm.controls; }

  onSubmit() {
    var item ={
      "noAgentsPrompt": this.noagentsForm.get('ismessageEnabled').value,
      "noAgentsDivert": this.noagentsForm.get('isCallEnabled').value,
      "noAgentsDN": this.noagentsForm.get('divertedNumber').value,
      "id":this.callFlowId,
    }
    console.log(item);
    this.dashboardService.updateNoagents(item).subscribe(
      data => {
        this.toasterService.pop("success", "Noagents", "File has been updated successfully");
      },
      error => {
        this.toasterService.pop("error", "Noagents", "Server error has occured!!!");
      });
  }
}
