import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DashboardService } from '../../provider/services/dashboard.service';
import { AuthenticationService } from '../../provider/services/authentication.service';
import { CallFlow } from '../../provider/models/callFlow';
import { ToasterService } from 'angular2-toaster';
import { MatDialog } from '@angular/material';
import { RemovecallflowComponent } from './removecallflow/removecallflow.component';


@Component({
  selector: 'app-callflow',
  templateUrl: './callflow.component.html',
  styleUrls: ['./callflow.component.css']
})
export class CallflowComponent implements OnInit {
  teamNames: any;
  callFlow: any;
 
  currentUser: any;
  displayedCallFlow: CallFlow[] = [];
  callflowarray: CallFlow[] = [];
  userId:any;

  constructor(private dashboardService: DashboardService,
    private authenticationService: AuthenticationService,private route: ActivatedRoute,private toasterService: ToasterService,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.userId= params["id"];
      if(this.userId){
        this.getTeams(this.userId);
      }
      else{
        this.getTeams(this.authenticationService.getUserDetails().sid);
      }
    });
  }

  private getTeams(userId) {
    let callFlowSelected=localStorage.getItem('CallFlowId');
    this.dashboardService.getTeams(userId).subscribe(
      data => {
        this.teamNames = data[0];
        this.callFlow = data[1].callFlows;
        this.callflowarray = data[0].text;
        console.log(data);
        let value = this.callFlow.filter(x => x.value == true);
        let finalValue = this.teamNames.filter(o1 => value.some(o2 => o1.id === o2.callFlowId));
        finalValue.map(x => {
          this.displayedCallFlow.push({ id: x.id, disabled: false, callFlowName: x.text });
        });
        
        if (!callFlowSelected || this.userId){
          this.displayedCallFlow[0].disabled = true;
          this.storeCurrentCallFlowDetails(this.displayedCallFlow[0]);
        }
        if (callFlowSelected && !this.userId) {
          let data = this.displayedCallFlow.find(x => x.id == callFlowSelected);
          let indexValue = this.displayedCallFlow.indexOf(data);
          this.displayedCallFlow[indexValue].disabled = true;
        }
        /*//test
        this.teamNames.map(x=>{
         this.displayedCallFlow.push({id : x.id,disabled:false,callFlowName:x.type});
        })
        if(!value){
        this.displayedCallFlow[0].disabled=true;
        this.storeCurrentCallFlowDetails(this.displayedCallFlow[0]);
        }
        if(value){
         let data=this.displayedCallFlow.find(x=>x.id==value);
         let indexValue =this.displayedCallFlow.indexOf(data);
         this.displayedCallFlow[indexValue].disabled=true;
        }*/
      },
      error => {
      });
  }

  selectedCallFlow(selectedFlow) {
    let indexValue = this.displayedCallFlow.indexOf(selectedFlow);
    this.displayedCallFlow.map(x => x.disabled = false);
    this.displayedCallFlow[indexValue].disabled = true;
    this.storeCurrentCallFlowDetails(this.displayedCallFlow[indexValue]);
  }
  storeCurrentCallFlowDetails(details: CallFlow) {
    localStorage.setItem('CallFlowId', details.id);
    localStorage.setItem('CallFlowName', details.callFlowName);
  }

  onsave()
 {
   this.displayedCallFlow.push(
     {
      id: "",
   callFlowName: null,
   disabled: false,
     }
   );
  }

  RemoveCallFlow(removecallflow)
 {
    let dialogRef = this.dialog.open(RemovecallflowComponent, { 
      panelClass:'custom-dialog-container',
      width: '500px',

    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.displayedCallFlow.splice(removecallflow,1);
        // this.dashboardService. deletecallflow(removeUserId).subscribe(
        //   data => {
           
        //     this.users.splice(indexValue,1);
        //     this.toasterService.pop("success", "CallFLow", "CallFlow has been deleted successfully");
        //   },
        //   error => {
        //     this.toasterService.pop("error", "CallFlow", "Server error has occured!!!");
        //   });
      }
    });
  }

  onsaveclick(){
    let abc:string=this.displayedCallFlow[this.displayedCallFlow.length-1].callFlowName;
    for(let i=0;i<(this.displayedCallFlow.length-1);i++)
    {
      if(this.displayedCallFlow[i].callFlowName==abc){
        this.toasterService.pop("error", "Addcallflow", "User is already exit");
      }
      else{
        this.dashboardService.AddCallFlow(abc).subscribe(
          data => {
             this.toasterService.pop("success", "Addcallflow", "Add user has been updated successfully");
           },
           error => {
             this.toasterService.pop("error", "Addcallflow", "Server error has occured!!!");
           });
      }
    }
  
     
  }
}
