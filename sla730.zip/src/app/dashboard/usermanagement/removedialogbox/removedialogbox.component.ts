import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-removedialogbox',
  templateUrl: 'removedialogbox.component.html',
})
export class RemoveDialogBoxComponent {

  constructor(
    public dialogRef: MatDialogRef<RemoveDialogBoxComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onOkClick(){
    this.dialogRef.close(true);
  }

}