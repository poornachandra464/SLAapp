import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../provider/services/dashboard.service';
import { MatDialog } from '@angular/material';
import { RemoveDialogBoxComponent } from './removedialogbox/removedialogbox.component';
import { ToasterService } from 'angular2-toaster';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.css']
})
export class UsermanagementComponent implements OnInit {
  users: any;

  constructor(private dashboardService: DashboardService,
    private router: Router,
    public dialog: MatDialog,
    private toasterService: ToasterService) { }

  ngOnInit() {
    this.dashboardService.getUserManagementDetails().subscribe(
      data => {
        this.users = data;
      },
      error => {
      });
  }

  OnGoClicked(userId){
   this.router.navigate(['dashboard/callflow/',userId])
  }

  OnRemoveClick(removeUserId){
    let dialogRef = this.dialog.open(RemoveDialogBoxComponent, { 
      panelClass:'custom-dialog-container',
      width: '500px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.dashboardService.deleteUserManagementDetail(removeUserId).subscribe(
          data => {
            let value=this.users.find(x=>x.id==removeUserId);
            let indexValue= this.users.indexOf(value);
            this.users.splice(indexValue,1);
            this.toasterService.pop("success", "User Management", "User has been deleted successfully");
          },
          error => {
            this.toasterService.pop("error", "User Management", "Server error has occured!!!");
          });
      }
    });
  }


}
