import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { CallflowComponent } from './callflow/callflow.component';
import { AuthGuardService as AuthGuard } from '../provider/services/auth-guard.service';
import { OpeningTimesComponent } from './opening-times/opening-times.component';
import { MessageComponent } from './message/message.component';
import { OutofhoursComponent } from './outofhours/outofhours.component'
import { HolidaysComponent } from './holidays/holidays.component';
import { NoAgentsComponent } from './noagents/noagents.component';
import { GeneralSettingsComponent } from './generalsettings/generalsettings.component';
import { GeneralCallSettingsComponent } from './generalcallsettings/generalcallsettings.component';
import { QueuingComponent } from './queuing/queuing.component';
import { DivertComponent } from './divert/divert.component';
import { AddUserComponent } from './usermanagement/add-user/add-user.component';
import { AuditLogComponent } from './auditlog/auditlog.component';

const routes: Routes = [
  {
    path: 'dashboard',
    resolve: {
    },
    children: [
      {
        path: 'usermanagement',
        component: UsermanagementComponent,
        canActivate: [AuthGuard],
        data: { roles: [] }
      },
      {
        path: 'callflow',
        component: CallflowComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'callflow/:id',
        component: CallflowComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'openingtimes',
        component: OpeningTimesComponent,
        canActivate: [AuthGuard],
        data: { isCallFlowSelected: localStorage.getItem('CallFlowId') }
      }, {
        path: 'message',
        component: MessageComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'outofhours',
        component: OutofhoursComponent,
        canActivate: [AuthGuard],
      }, {
        path: 'holidays',
        component: HolidaysComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'noagents',
        component: NoAgentsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'general',
        component: GeneralSettingsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'generalCall',
        component: GeneralCallSettingsComponent,
        canActivate: [AuthGuard],
      },
      {
        path:'queuing',
        component:QueuingComponent,
        canActivate:[AuthGuard],
      },
      {
        path:'divert',
        component:DivertComponent,
        canActivate:[AuthGuard],
      },
      {
        path:'adduser',
        component:AddUserComponent,
        canActivate: [AuthGuard],
      },
      {
        path:'auditlog',
        component:AuditLogComponent,
        canActivate: [AuthGuard],
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {
  ngOnInit(){
   //routes[0].children[0].data={roles :["01","03","06"]};
   
  }
 }
