export class CallFlowData{
    CallFlowId:string; 
    Value:boolean; 
}