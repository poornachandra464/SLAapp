import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-of-the-day',
  templateUrl: './message-of-the-day.component.html',
  styleUrls: ['./message-of-the-day.component.css']
})
export class MessageOfTheDayComponent implements OnInit {

  constructor() { }
  msg:number;
  a:number[];
  x:boolean;
  enablePlayMotd:any;
  ngOnInit() {
    this.msg=3;
    this.x=false;
      this.a=Array(this.msg).fill(1).map((x,y)=>y+1);
  }

}
