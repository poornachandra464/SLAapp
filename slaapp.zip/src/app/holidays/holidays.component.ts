import { Component, OnInit } from '@angular/core';
import {HolidayService} from '../holiday.service';

@Component({
  selector: 'app-holidays',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.css']
})
export class HolidaysComponent implements OnInit {
  
  IndividualMessages:boolean;
  checkHolidayDays:boolean;
  Holidays=[
   {date:'25/12/2019',start:'10:10',end:'23:00',close:true},
   {date:'08/12/2019',start:'09:46',end:'22:00',close:false},
   {date:'07/12/2019',start:'08:10',end:'21:00',close:true},

 ]
   
  constructor(private holidayservice:HolidayService) {}

  ngOnInit() {
  
   /* this.holidayservice.GetHolidayDetails().subscribe(
      data => this.Holiday = data );*/
  }
  Remove(a)
  {
    this.Holidays.splice(a,1);
  }

}
