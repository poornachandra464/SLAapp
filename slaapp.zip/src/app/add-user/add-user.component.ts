import { Component, OnInit } from '@angular/core';
import{FormControl, FormGroup} from '@angular/forms';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  UserForm= new FormGroup({
    UserId:new FormControl(''),
    PassWord:new FormControl(''),
  })
  Teams:Array<string>=['Global Client Ops','Investor Services','ASC']   


  constructor() { }

  ngOnInit() {
  }

}
