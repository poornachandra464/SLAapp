import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor() { }
  DDIS:number [];
  IVR_Option:any;

  ngOnInit() {
    this.DDIS=[1,2,3,4,5];
  }

}
