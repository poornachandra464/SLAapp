import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { Url } from 'url';
@Injectable({
  providedIn: 'root'
})
export class HolidayService {

  constructor(private http:HttpClient) { }
    
    GetHolidayDetails()
    {
    // return this.http.get();
    }
    PutHolidayDetails()
    {
      //return this.http.put();
    }

}
