import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opening-times',
  templateUrl: './opening-times.component.html',
  styleUrls: ['./opening-times.component.css']
})
export class OpeningTimesComponent implements OnInit {

  constructor() { }
   checkHolidayDays:boolean;
   mondayStart:any;
  ngOnInit() {
    this.mondayStart="11:30";
    this.checkHolidayDays=false;
  }

}
