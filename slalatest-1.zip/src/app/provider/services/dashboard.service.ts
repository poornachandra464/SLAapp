import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable,forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user';
import {CallFlow} from '../models/callFlow';
import {messageOfTheDay} from '../models/messageOfTheDay';
import { OpeningTimes } from '../models/openingTimes';


@Injectable({ providedIn: 'root' })
export class DashboardService {
    private serviceUrl = "https://localhost:44362/api/";
    userCredentials:User;

    constructor(private http: HttpClient){}

    getUserManagementDetails(): Observable<any> {
      return this.http.get<any>(this.serviceUrl+"UserManagement")
      .pipe(map(user => {
        return user
      }));
    }

    getTeams(): Observable<any> {
      let teamName = this.http.get(this.serviceUrl+"CallFlow/Teams");
      let callFlow = this.http.get(this.serviceUrl+"CallFlow");
      return forkJoin([teamName,callFlow]).pipe(map((resspone: any) => {
        console.log(resspone)
        return resspone;
    }));
    }

    getOpeningTimes(callFlowId: string): Observable<any> {
      return this.http.get(this.serviceUrl + "OpeningTimes?callFlowId=" + callFlowId)
        .pipe(map((response: any) => {
          return response;
        }));
    }
    
  updateOpeningTimes(openingTimesModel: OpeningTimes): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.serviceUrl + "OpeningTimes", openingTimesModel, { headers: headers })
      .pipe(map((response: any) => {
        console.log(response);
      }));
  }

    getMessageDetails():Observable<any>{
      let callFlowId={'callFlowId':localStorage.getItem('CallFlowId')}
      return this.http.get<any>(this.serviceUrl+"MessageOfTheDay",{params:callFlowId})
      .pipe(map(data => {
        return data
      }));
    }

    updateMessageDetails(messageModel:messageOfTheDay){
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.serviceUrl + "MessageOfTheDay", messageModel, { headers: headers })
      .pipe(map((response: any) => {
      console.log(response);
      return response;
      }));
    }
}