export class messageOfTheDay {
    enablePlayMotd:boolean;
    motdMessage:number;
    motdCounter:number;
    id?:string;
 }