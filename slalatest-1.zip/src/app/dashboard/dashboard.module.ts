import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BsDatepickerModule, PaginationModule, BsModalService, ProgressbarModule,  } from 'ngx-bootstrap';
import { ChartsModule } from 'ng2-charts';
import { ToasterModule } from 'angular2-toaster';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from '../app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';

import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { CallflowComponent } from './callflow/callflow.component';
import { OpeningTimesComponent } from './opening-times/opening-times.component';
import {MessageComponent} from './message/message.component';
import {OutofhoursComponent} from './outofhours/outofhours.component';

import { DashboardRoutingModule } from './dashboard-routing.module';

@NgModule({
  declarations: [
    UsermanagementComponent,
    CallflowComponent,
    OpeningTimesComponent,
    MessageComponent,
    OutofhoursComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    ChartsModule,
    Ng4LoadingSpinnerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    ProgressbarModule.forRoot(),
    ToasterModule.forRoot(),
    DashboardRoutingModule,
    NgxMaterialTimepickerModule
  ],
  providers: [
    BsModalService,
  ],
  entryComponents: [
   
  ]
})
export class DashboardModule { }
