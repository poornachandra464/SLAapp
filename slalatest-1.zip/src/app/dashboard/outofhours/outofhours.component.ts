import { Component, OnInit } from '@angular/core';
import {DashboardService} from '../../provider/services/dashboard.service';

@Component({
  selector: 'app-outofhours',
  templateUrl: './outofhours.component.html',
  styleUrls: ['./outofhours.component.css']
})
export class OutofhoursComponent implements OnInit {
  enabledMessageNumber:any;
  enabledMessageCall:any;
  enabledMessage:any;
  constructor(private dashboardService:DashboardService) { 
   
  }
  ngOnInit() { 

  }

}
