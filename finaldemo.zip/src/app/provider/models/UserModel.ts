import { CallFlowData } from './CallFlowData';

export class UserModel{
    userName:string;

        password:string;

        accountType:string;

        callFlows:CallFlowData[];
}